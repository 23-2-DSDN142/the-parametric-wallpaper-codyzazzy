// Parameter variables
let rect_width  = 1400;
let rect_height = 140;
let rectx = 0;
let recty = 0;
let mystrokeWeight = 6;
let translatex = 100;
let translatey = 0;
let rect_fill_color = '#FFF5E0'; // null means no fill color, otherwise specify the color
let stroke1 = '#FFADAD';
let stroke2 = '#FFD6A5';
let stroke3 = '#FFC3A0';
let stroke4 = '#FFA0A0';
let stroke5 = '#FFB3B8';
let stroke6 = '#FFB6C1';
function setup_wallpaper(pWallpaper) {
  pWallpaper.output_mode(GRID_WALLPAPER);
  pWallpaper.resolution(NINE_LANDSCAPE);
  pWallpaper.show_guide(false);

  // Grid settings
  pWallpaper.grid_settings.cell_width  = 200;
  pWallpaper.grid_settings.cell_height = 200;
  pWallpaper.grid_settings.row_offset  = 50;
}

function wallpaper_background() {
  background(240, 255, 240);
}

function my_symbol() {
  // If rect_fill_color is specified, use it
  if (rect_fill_color) {
    fill(rect_fill_color);
  }

  // First rectangle
  push();
  translate(translatex, translatey);
  rotate(45);
  stroke(stroke1);  // RGB for #FFADAD
  strokeWeight(mystrokeWeight);
  rect(recty, rectx, rect_width, rect_height);
  pop();

  // Second rectangle
  push();
  translate(translatex + 6, translatey + 15);
  rotate(50);
  stroke(stroke2);  // RGB for #FFD6A5
  strokeWeight(mystrokeWeight - 1);
  rect(recty * 0.85, rectx * 0.85, rect_width * 0.85, rect_height * 0.85);
  pop();

  // Third rectangle
  push();
  translate(translatex + 6, translatey + 30);
  rotate(55);
  stroke(stroke3);  // RGB for #FFC3A0
  strokeWeight(mystrokeWeight - 2);
  rect(recty * 0.7, rectx * 0.7, rect_width * 0.7, rect_height * 0.7);
  pop();

  // Fourth rectangle
  push();
  translate(translatex + 6, translatey + 45);
  rotate(60);
  stroke(stroke4);  // RGB for #FFA0A0
  strokeWeight(mystrokeWeight - 3);
  rect(recty * 0.55, rectx * 0.55, rect_width * 0.55, rect_height * 0.55);
  pop();

  // Fifth rectangle
  push();
  translate(translatex + 6, translatey + 60);
  rotate(65);
  stroke(stroke5);  // RGB for #FFB3B8
  strokeWeight(mystrokeWeight - 4);
  rect(recty * 0.4, rectx * 0.4, rect_width * 0.4, rect_height * 0.4);
  pop();

  // Sixth rectangle
  push();
  translate(translatex + 6, translatey + 75);
  rotate(70);
  stroke(stroke6);  // RGB for #FFB0FF
  strokeWeight(mystrokeWeight - 4);
  rect(recty * 0.25, rectx * 0.25, rect_width * 0.25, rect_height * 0.25);
  pop();
}
